import{at as n}from"./vendor.551cd33e.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
