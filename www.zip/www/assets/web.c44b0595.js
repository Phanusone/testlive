import{ar as n}from"./vendor.accd9808.js";class o extends n{async show(e){}async hide(e){}}export{o as SplashScreenWeb};
