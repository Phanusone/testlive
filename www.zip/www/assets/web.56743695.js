import{aq as n}from"./vendor.bd96f6bb.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
