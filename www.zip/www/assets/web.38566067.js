import{ar as n}from"./vendor.1a5ba74c.js";class o extends n{async show(e){}async hide(e){}}export{o as SplashScreenWeb};
