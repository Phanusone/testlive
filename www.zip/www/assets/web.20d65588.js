import{ar as n}from"./vendor.d51ed549.js";class d extends n{async show(e){}async hide(e){}}export{d as SplashScreenWeb};
