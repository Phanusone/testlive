import{ar as n}from"./vendor.76c2f6c3.js";class o extends n{async show(e){}async hide(e){}}export{o as SplashScreenWeb};
